(function($) {
	var url = 'http://192.168.22.187/~terry/pinet-app/coordination.php';
	var serverok = '/serverok.json';
	var wait = 2000;

	function get(url, callback)
	{
		var options = {
			url: url,
			type: 'GET',
			success: callback,
			dataType: "json",
			crossDomain: true
		};
		if (arguments.length > 2) {
			$.extend(options, arguments[2]);
		}

		$.ajax(options);
	}

	var $a = $('#jump2home');
	var done = false;
	setTimeout(function() {
		if (done) {
			window.location.href = $a.attr('href');
		}
	}, wait);

	get(url, function(resp) {
		var i, n = resp.length;
		var args = { timeout: 200 };
		for (i = 0; i < n; i++) {
			(function(server) {
				get('//'+ server + serverok, function(ok) {
					if (true === ok && false === done) {
						$('.logo img').show();
						$a.attr('href', $a.attr('href') +'#'+ server);
						done = true;
					}
				}, args);
			})(resp[i]);
		}
	});

})(jQuery);
